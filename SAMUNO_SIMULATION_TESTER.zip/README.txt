To update model parameters, edit: init_parts.m

To create the joint Trajectory, edit: Traj_Creator.m

To start the GUI, run: createSimulinkGUI_2024b
	- Load in your joint positions (generated from Traj_Creator.m) 
	- If you like the outcome, record your Trial Data

If you need to update the model itself- Change Samuno_Experimental_2024b

